import React from 'react'

const Teleconsultation2 = () => {
  return (
    <div>
      Teleconsultation2
    </div>
  )
}

export default Teleconsultation2
